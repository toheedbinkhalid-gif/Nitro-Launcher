package com.nitro.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Neon = Color(0xFF39FF14)
private val Background = Color(0xFF080B09)
private val Panel = Color(0xFF121A14)
private val Muted = Color(0xFFB7C2B9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NitroApp() }
    }
}

@Composable
fun NitroApp() {
    var selectedTab by remember { mutableStateOf("Home") }
    var dialogText by remember { mutableStateOf<String?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Neon, onPrimary = Color.Black,
        background = Background, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D120E)) {
                    listOf("Home", "Library", "Settings").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    when (tab) {
                                        "Library" -> Icons.Default.ViewModule
                                        "Settings" -> Icons.Default.Settings
                                        else -> Icons.Default.Home
                                    }, contentDescription = tab
                                )
                            },
                            label = { Text(tab) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Neon,
                                selectedTextColor = Neon,
                                indicatorColor = Color(0xFF203A22),
                                unselectedTextColor = Muted,
                                unselectedIconColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("N", color = Neon, fontSize = 38.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("NITRO LAUNCHER", fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text("GAMING WITHOUT LIMITS", color = Neon, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = Neon, modifier = Modifier.size(30.dp))
                    }
                }
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF142319)),
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier.fillMaxWidth().border(1.dp, Neon.copy(alpha = .7f), RoundedCornerShape(22.dp))
                    ) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ONE LAUNCHER.", color = Neon, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("THREE WORLDS.", fontSize = 30.sp, fontWeight = FontWeight.Black)
                            Text("Choose your game and explore your library.", color = Muted)
                            Text("JAVA  •  BEDROCK  •  RUST", color = Neon, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                item { Text("YOUR GAMES", color = Neon, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
                item {
                    GameCard(
                        title = "Minecraft Java Edition",
                        subtitle = "PC edition • Java runtime required",
                        symbol = "⛏",
                        details = "Java Edition is a desktop game. This Android app currently provides a launcher-style dashboard only. To play on Android, a compatible third-party Java runtime/launcher and your own legally obtained game files are required.",
                        onClick = { dialogText = "Minecraft Java Edition\n\nJava Edition is designed for PC. Nitro Launcher currently shows the game section only; it does not include a Java runtime or game files." }
                    )
                }
                item {
                    GameCard(
                        title = "Minecraft Bedrock Edition",
                        subtitle = "Android edition • Official app required",
                        symbol = "◆",
                        details = "Install or open the official Minecraft app from a trusted store. Nitro Launcher does not bundle the game.",
                        onClick = { dialogText = "Minecraft Bedrock Edition\n\nInstall the official Minecraft app from Google Play. This demo does not install, modify, or launch the paid game." }
                    )
                }
                item {
                    GameCard(
                        title = "Rust",
                        subtitle = "PC survival game • No native Android edition",
                        symbol = "⚒",
                        details = "Rust for PC does not have an official native Android edition. This section is an information/library card, not a playable Android port.",
                        onClick = { dialogText = "Rust\n\nRust is a PC game and has no official native Android edition. This card is informational only." }
                    )
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, tint = Neon, contentDescription = null)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("NITRO UI READY", color = Neon, fontWeight = FontWeight.Bold)
                                Text("Version 1.0.0 • Demo launcher interface", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
        dialogText?.let { message ->
            AlertDialog(
                onDismissRequest = { dialogText = null },
                containerColor = Panel,
                title = { Text("Nitro Launcher", color = Neon, fontWeight = FontWeight.Bold) },
                text = { Text(message, color = Color.White) },
                confirmButton = {
                    TextButton(onClick = { dialogText = null }) { Text("OK", color = Neon) }
                }
            )
        }
    }
}

@Composable
fun GameCard(
    title: String,
    subtitle: String,
    symbol: String,
    details: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, Neon.copy(alpha = .65f), RoundedCornerShape(20.dp))
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(48.dp).background(Color(0xFF203A22), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Text(symbol, color = Neon, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(subtitle, color = Muted, fontSize = 11.sp)
                }
            }
            Button(
                onClick = onClick,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Color.Black),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("OPEN SECTION", fontWeight = FontWeight.Black)
            }
        }
    }
}
