# Nitro Launcher — Android Kotlin starter

Black + neon-green Compose UI with Java, Bedrock, and Rust sections.

## Open and build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `NitroLauncher` folder.
4. Let Gradle sync finish.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show the generated APK location.

## Important scope notes
This is a launcher-style dashboard starter, not a working game installer or emulator:
- Minecraft Java Edition is a desktop edition and needs a compatible Android Java runtime/launcher plus the user's own game files and account.
- Minecraft Bedrock should be installed from the official store; this project does not bundle or bypass its purchase.
- Rust is a PC game and has no official native Android edition. The Rust section is informational.
- The three buttons open clear information dialogs; they do not falsely claim to launch games.

No game assets, proprietary logos, accounts, or game files are included.
